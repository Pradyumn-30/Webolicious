from flask import Flask, render_template, request, redirect,flash
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
import jinja2

#THIS IS TO ESTABLISHING THE CONNECTION WITH DB
import mysql.connector

mydb =mysql.connector.connect(
        host="localhost",
        user="root",
        password="Zensri@30",
        database="my_database",
        auth_plugin='mysql_native_password'
        )
#THIS IS TO SET THE FLASK PROPERTY
app = Flask(__name__)
app.secret_key = 'secret key'

@app.route('/')
def home():
    return render_template('first_home2.html')

@app.route('/list_user')
def list_view():
    mycursor=mydb.cursor()
    mycursor.execute("select * from doctor")
    response=mycursor.fetchall()
    data = pd.read_sql("select * from doctor",mydb)
    print(data.head())
    sns.barplot(x='doc_name',y='nump',data=data)
    plt.xlabel('Doctor Name')
    plt.ylabel('NumberOfPatients')
    plt.title('Number of patients seen by doctor')
    plt.savefig('static/doc_num.jpg')
    return render_template('demo_list.html',response=response)

    


